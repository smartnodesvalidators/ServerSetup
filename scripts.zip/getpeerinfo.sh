echo "$(BINARY tendermint show-node-id)@$(curl ifconfig.me):26656"
