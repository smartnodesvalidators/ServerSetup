BINARY query slashing signing-infos --output json | jq | grep <valcons_address>
