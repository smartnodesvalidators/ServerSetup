BINARY tx ibc-transfer transfer transfer channel-x <destination_address> 1denom --from xxx --gas xxx
