curl http://localhost:26657/status | jq .result.sync_info.catching_up
