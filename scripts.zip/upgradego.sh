sudo apt remove golang-go -y
sudo apt update
sudo apt install golang-go -y
