tx distribution withdraw-rewards sentvaloper1652j9a730n59055exyr830w0z0pyg7xu3jczwh --commission --chain-id sentinelhub-2 --from "SmartNodes" --broadcast-mode block --gas-prices=0.25udvpn
